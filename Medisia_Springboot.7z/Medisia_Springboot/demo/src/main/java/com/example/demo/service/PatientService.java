package com.example.demo.service;
import com.example.demo.model.Patient;
import com.example.demo.repo.SignupRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientService {

    @Autowired
    private SignupRepository userRepository;

    public String registerUser(Patient user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            return "Username is already taken.";
        }

        if (userRepository.existsByEmail(user.getEmail())) {
            return "Email is already registered.";
        }

        if (userRepository.existsByMobile(user.getMobile())) {
            return "Mobile number is already registered.";
        }

        user.setPassword(encryptPassword(user.getPassword())); // Encrypt the password
        userRepository.save(user);
        return "User registered successfully!";
    }

    private String encryptPassword(String password) {
        // Add password encryption logic (e.g., BCrypt)
    	
        return password;
    }
}
