package com.example.demo.controller;

import com.example.demo.model.Login;
import com.example.demo.model.Patient;
import com.example.demo.repo.LoginRepository;
import com.example.demo.repo.SignupRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class SignupController {

    @Autowired
    private SignupRepository userRepository;

    @Autowired
    private LoginRepository loginRepository;

    @PostMapping("/signup")
    public ResponseEntity<String> registerUser(@RequestBody Patient user) {
        // Check if username already exists
    	if (userRepository.existsByUsername(user.getUsername())) {
    	    return ResponseEntity.badRequest().body("Username already exists.");
    	}


        // Save user details in the User table
        userRepository.save(user);

        // Save username and password in the Login table
        Login login = new Login();
        login.setUsername(user.getUsername());
        login.setPassword(user.getPassword());
        loginRepository.save(login);

        return ResponseEntity.ok("User registered successfully!");
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestParam String username, @RequestParam String password) {
        // Validate credentials from the Login table
        Login login = loginRepository.findByUsername(username);
        if (login != null && login.getPassword().equals(password)) {
            return ResponseEntity.ok("Login successful!");
        } else {
            return ResponseEntity.status(401).body("Invalid username or password.");
        }
    }
}
