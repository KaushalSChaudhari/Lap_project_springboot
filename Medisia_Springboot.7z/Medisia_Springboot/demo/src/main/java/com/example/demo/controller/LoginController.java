package com.example.demo.controller;

import com.example.demo.model.Login;
import com.example.demo.repo.LoginRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private LoginRepository loginRepository;

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestParam String username, @RequestParam String password) {
        // Check if user exists in the login table
        Login login = loginRepository.findByUsername(username);
        if (login != null && login.getPassword().equals(password)) {
            return ResponseEntity.ok("Login successful!");
        } else {
            return ResponseEntity.status(401).body("Invalid username or password.");
        }
    }

    @PostMapping("/register-login")
    public ResponseEntity<String> registerLogin(@RequestBody Login login) {
        if (loginRepository.findByUsername(login.getUsername()) != null) {
            return ResponseEntity.badRequest().body("Username already exists.");
        }
        loginRepository.save(login);
        return ResponseEntity.ok("Login information saved successfully!");
    }
}


